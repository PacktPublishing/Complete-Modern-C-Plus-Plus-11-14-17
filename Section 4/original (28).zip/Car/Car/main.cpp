#include "Car.h"
#include<iostream>
int main() {
	Car c(5);
	c.Dashboard();
	return 0;
}
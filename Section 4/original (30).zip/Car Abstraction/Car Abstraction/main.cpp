#include "Car.h"
int main() {
	Car c;

	return 0;
}
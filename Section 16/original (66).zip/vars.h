#pragma once
inline int global ;
class Test {
	inline static int m_Data = 50 ;
	constexpr static int PATHSIZE=  255 ;
	int x = 5 ;
};
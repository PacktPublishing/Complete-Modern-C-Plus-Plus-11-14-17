#include <iostream>
#include "vars.h"

int main() {
	
}